import './App.css';
import Mainroutes from './components/Mainroutes';
import Nav from './components/Navbar';

function App() {
  return  <div>
    <br></br>
    <Nav/>
    <Mainroutes/>
  </div>
}

export default App;
